// Authored route puzzle. Positions are metres; costs are lantern units, not seconds.
export const CAPACITY=12;
export const NODES=[
 {id:'field',name:'The shepherd’s field',x:0,z:36,fire:true,chapter:'Outside Bethlehem',note:'Beyond the fields, a few windows hold the night.'},
 {id:'gate',name:'The village threshold',x:0,z:20,chapter:'At the threshold',note:'The shortest way crosses the wind. The olive court offers shelter.'},
 {id:'olive',name:'Olive courtyard',x:-15,z:7,fire:true,chapter:'Among the first houses',note:'A sheltered flame. Your lantern is full again.'},
 {id:'well',name:'The old well',x:13,z:7,chapter:'The quiet well',note:'No flame here. Keep enough light to reach the courtyard ahead.'},
 {id:'market',name:'Sleeping market',x:-18,z:-9,chapter:'The sleeping village',note:'Empty baskets, folded cloth. The narrow lane shelters your light.'},
 {id:'square',name:'Lantern courtyard',x:3,z:-11,fire:true,chapter:'The sleeping village',note:'Warmth in the quiet courtyard. Your lantern is full again.'},
 {id:'ridge',name:'The exposed ridge',x:28,z:-5,chapter:'Above the rooftops',note:'You can see the destination, but wind makes this a costly way.'},
 {id:'lookout',name:'The hillside overlook',x:-32,z:-4,chapter:'A moment above the village',note:'A beautiful view, but the lane ends here. Retrace or return to your last flame.'},
 {id:'arch',name:'The last hearth',x:-8,z:-26,fire:true,chapter:'Beyond the last houses',note:'One last sheltered flame. The open stall is close.'},
 {id:'pen',name:'The sheep fold',x:18,z:-25,chapter:'Beyond the last houses',note:'A quiet fold. The final path is exposed; check your light before setting out.'},
 {id:'goal',name:'The open stall',x:3,z:-43,chapter:'Good news. Great joy.',note:'The journey ends at the manger.'}
];
export const EDGES=[
 ['field','gate',3,'Field path'],['gate','olive',4,'Sheltered lane'],['gate','well',5,'Stone lane'],['gate','ridge',10,'Windy shortcut'],
 ['olive','market',4,'Under the olive trees'],['olive','lookout',7,'Hillside trail'],['well','square',3,'Between the houses'],
 ['well','ridge',6,'Exposed steps'],['market','square',4,'Market passage'],['market','arch',5,'Sheltered passage'],
 ['square','arch',4,'By the low wall'],['square','pen',4,'Past the sheep fold'],['square','ridge',6,'Rooftop path'],
 ['ridge','pen',5,'Windward lane'],['arch','goal',7,'The final path'],['pen','goal',9,'Open hillside']
].map(([a,b,cost,name],i)=>({id:`lane-${i}`,a,b,cost,name,exposed:/Wind|wind|Exposed|Open|Rooftop/.test(name)}));
export const NODE=Object.fromEntries(NODES.map(n=>[n.id,n]));
export function links(id){return EDGES.filter(e=>e.a===id||e.b===id).map(e=>({...e,to:e.a===id?e.b:e.a})).sort((a,b)=>NODE[a.to].x-NODE[b.to].x||NODE[a.to].z-NODE[b.to].z);}
export function lanePoints(edge){const a=NODE[edge.a],b=NODE[edge.b];const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz);return Array.from({length:25},(_,i)=>{const t=i/24,bend=Math.sin(t*Math.PI)*1.15;return {x:a.x+dx*t-dz/len*bend,z:a.z+dz*t+dx/len*bend};});}
export class Journey{
 constructor(){this.reset();}
 reset(){this.at='field';this.light=CAPACITY;this.checkpoint='field';this.previous=null;this.travel=null;this.phase='intro';this.paused=false;this.selected=0;this.survey=false;this.visited=new Set(['field']);this.distance=0;this.recoveries=0;this.message='';this.decisions=0;}
 get options(){return links(this.at);}
 get choice(){return this.options[this.selected];}
 start(){if(this.phase!=='intro')return false;this.phase='choice';return true;}
 select(delta){if(this.phase!=='choice'||this.paused)return false;this.selected=(this.selected+delta+this.options.length)%this.options.length;this.message='';return true;}
 commit(edge=this.choice){
  if(this.phase!=='choice'||this.paused||!edge||!this.options.some(e=>e.id===edge.id&&e.to===edge.to))return false;
  if(edge.cost>this.light){this.message='Not enough light for this lane. Choose shelter, or return to your last flame.';return false;}
  const raw=lanePoints(edge),points=edge.a===this.at?raw:raw.slice().reverse();
  const lengths=points.slice(1).map((p,i)=>Math.hypot(p.x-points[i].x,p.z-points[i].z));
  this.travel={edge,from:this.at,to:edge.to,points,lengths,length:lengths.reduce((a,b)=>a+b,0),progress:0,startLight:this.light};
  this.phase='walking';this.survey=false;this.message='';this.decisions++;return true;
 }
 back(){const edge=this.options.find(e=>e.to===this.previous);return this.commit(edge||null);}
 recover(){if(this.phase!=='choice'&&this.phase!=='walking')return false;this.at=this.checkpoint;this.light=CAPACITY;this.travel=null;this.phase='choice';this.paused=false;this.previous=null;this.selected=0;this.recoveries++;this.message='Back at your last flame. Your discoveries are kept.';return true;}
 step(dt){
  if(this.phase!=='walking'||this.paused||!Number.isFinite(dt)||dt<=0)return;
  const t=this.travel,amount=Math.min(dt*3.1,t.length-t.progress);t.progress+=amount;this.distance+=amount;
  this.light=Math.max(0,t.startLight-t.edge.cost*t.progress/t.length);
  if(t.progress>=t.length-1e-8){
   this.previous=t.from;this.at=t.to;this.light=Math.max(0,t.startLight-t.edge.cost);this.visited.add(this.at);this.travel=null;
   if(NODE[this.at].fire){this.light=CAPACITY;this.checkpoint=this.at;}
   this.phase=this.at==='goal'?'arrival':'choice';this.selected=Math.max(0,this.options.findIndex(e=>e.to!==this.previous));
  }
 }
 get position(){
  if(!this.travel)return {...NODE[this.at]};
  let d=this.travel.progress;const {points,lengths}=this.travel;
  for(let i=0;i<lengths.length;i++){if(d<=lengths[i]){const f=d/lengths[i];return {x:points[i].x+(points[i+1].x-points[i].x)*f,z:points[i].z+(points[i+1].z-points[i].z)*f,heading:Math.atan2(points[i+1].x-points[i].x,points[i+1].z-points[i].z)};}d-=lengths[i];}
  return {...NODE[this.travel.to]};
 }
 snapshot(){return {at:this.at,phase:this.phase,light:this.light,checkpoint:this.checkpoint,paused:this.paused,selected:this.choice?.to,visited:[...this.visited],distance:this.distance,recoveries:this.recoveries,decisions:this.decisions,position:this.position};}
}
