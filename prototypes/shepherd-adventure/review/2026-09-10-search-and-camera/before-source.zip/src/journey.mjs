import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {CharacterVariants} from './character-variants.mjs';
import {Journey,NODE,NODES,EDGES,CAPACITY,lanePoints} from './journey-model.mjs';
import {createJourneyWorld,height} from './journey-world.mjs';

const $=s=>document.querySelector(s),journey=new Journey();
const renderer=new THREE.WebGLRenderer({canvas:$('#world'),antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
const scene=new THREE.Scene();scene.background=new THREE.Color('#071320');scene.fog=new THREE.FogExp2('#102132',.008);
const camera=new THREE.PerspectiveCamera(49,innerWidth/innerHeight,.1,500);
scene.add(new THREE.HemisphereLight('#91b6dd','#26231c',.65));
const moon=new THREE.DirectionalLight('#93b7e9',1.05);moon.position.set(-35,50,25);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);Object.assign(moon.shadow.camera,{left:-55,right:55,top:65,bottom:-65,near:1,far:160});moon.shadow.normalBias=.06;moon.shadow.bias=-.0003;scene.add(moon,moon.target);
const world=createJourneyWorld(scene),avatar=new THREE.Group();scene.add(avatar);const characters=new CharacterVariants(avatar);
let ready=false,last=0,clock=0,signature='',oldPhase='intro',menuIndex=0,heading=Math.PI,desiredHeading=Math.PI,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const held=new Set(),camTarget=new THREE.Vector3(),lookTarget=new THREE.Vector3(),look=new THREE.Vector3(),labelEntries=[];
for(let i=0;i<CAPACITY;i++)$('#light-bars').append(document.createElement('i'));
function label(text,p,cls,meta={}){const el=document.createElement('div');el.className=`world-label ${cls}`;el.textContent=text;$('#labels').append(el);labelEntries.push({el,p,...meta});}
for(const n of NODES)label((n.fire?'● ':n.id==='goal'?'◇ ':'')+n.name,{x:n.x,y:2.4,z:n.z},n.fire?'fire':'',{node:n.id});
for(const e of EDGES){const p=lanePoints(e)[12];label(String(e.cost),{...p,y:.55},'cost',{edge:e.id});}

let audioContext,audioGain,sound=false,spoken='';
function speak(text){if(!sound||!('speechSynthesis' in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.87;u.volume=.85;speechSynthesis.speak(u);}
async function toggleSound(){
 sound=!sound;$('#sound').textContent=sound?'Sound on':'Sound off';$('#sound').setAttribute('aria-pressed',String(sound));
 if(sound){try{if(!audioContext){audioContext=new AudioContext();audioGain=audioContext.createGain();audioGain.gain.value=.026;audioGain.connect(audioContext.destination);
  for(const f of [146.83,220,293.66]){const o=audioContext.createOscillator();o.type='sine';o.frequency.value=f;const g=audioContext.createGain();g.gain.value=.14;o.connect(g);g.connect(audioGain);o.start();}
  const buffer=audioContext.createBuffer(1,audioContext.sampleRate*3,audioContext.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;const noise=audioContext.createBufferSource();noise.buffer=buffer;noise.loop=true;const filter=audioContext.createBiquadFilter();filter.type='lowpass';filter.frequency.value=340;noise.connect(filter);filter.connect(audioGain);noise.start();
 }await audioContext.resume();speak(journey.phase==='intro'?$('#intro>p').textContent:journey.phase==='arrival'?$('#ending>p').textContent:NODE[journey.at].note);}catch{sound=false;$('#sound').textContent='Sound unavailable';}}
 else{audioContext?.suspend();if('speechSynthesis' in window)speechSynthesis.cancel();}
}
function ding(){if(!sound||!audioContext)return;const o=audioContext.createOscillator(),g=audioContext.createGain();o.frequency.value=587.33;o.type='sine';o.connect(g);g.connect(audioContext.destination);g.gain.setValueAtTime(.045,audioContext.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+1.8);o.start();o.stop(audioContext.currentTime+1.8);}
function reset(){journey.reset();signature='';oldPhase='intro';heading=desiredHeading=Math.PI;spoken='';if('speechSynthesis' in window)speechSynthesis.cancel();updateUI();updateCamera(1,true);}
function begin(){if(!ready)return;journey.start();updateUI();}
const menuButtons=[$('#resume'),$('#back'),$('#recover'),$('#restart')];
function showPause(value){if(!ready||!['choice','walking'].includes(journey.phase))return;journey.paused=value;menuIndex=0;$('#back').disabled=journey.phase!=='choice'||!journey.previous;focusMenu();if('speechSynthesis' in window){if(value)speechSynthesis.pause();else speechSynthesis.resume();}updateUI();}
function focusMenu(){menuButtons.forEach((b,i)=>b.classList.toggle('selected',i===menuIndex));if(journey.paused)menuButtons[menuIndex].focus({preventScroll:true});else document.activeElement?.blur();}
function recover(){journey.recover();document.activeElement?.blur();updateUI();updateCamera(1,true);}
function input(key){
 if(!ready)return;
 if(journey.phase==='intro'){if(['Enter',' ','Select'].includes(key))begin();else if(key==='ArrowUp')toggleSound();return;}
 if(journey.phase==='arrival'){if(['Enter',' ','Select'].includes(key))reset();return;}
 if(journey.paused){if(key==='ArrowDown'||key==='ArrowUp'){do{menuIndex=(menuIndex+(key==='ArrowUp'?-1:1)+menuButtons.length)%menuButtons.length;}while(menuButtons[menuIndex].disabled);focusMenu();}else if(['Enter',' ','Select'].includes(key))menuButtons[menuIndex].click();else if(key==='Escape')showPause(false);return;}
 if(key==='ArrowDown'||key==='Escape'||key==='p'||key==='P'){showPause(true);return;}
 if(key==='ArrowUp'){journey.survey=!journey.survey;updateUI();return;}
 if(journey.phase==='walking'){if(['Enter',' ','Select'].includes(key))showPause(true);return;}
 if(key==='ArrowLeft')journey.select(-1);else if(key==='ArrowRight')journey.select(1);else if(['Enter',' ','Select'].includes(key))journey.commit();updateUI();
}
$('#begin').onclick=begin;$('#prev').onclick=()=>input('ArrowLeft');$('#next').onclick=()=>input('ArrowRight');$('#commit').onclick=()=>input('Enter');$('#survey').onclick=()=>input('ArrowUp');$('#pause').onclick=()=>showPause(true);$('#resume').onclick=()=>showPause(false);$('#back').onclick=()=>{showPause(false);journey.back();updateUI();};$('#recover').onclick=recover;$('#restart').onclick=reset;$('#again').onclick=reset;$('#sound').onclick=toggleSound;
addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter',' ','Select','Escape','p','P'].includes(e.key)){e.preventDefault();if(e.repeat||held.has(e.key))return;held.add(e.key);input(e.key);}});addEventListener('keyup',e=>held.delete(e.key));
function blur(){held.clear();if(['choice','walking'].includes(journey.phase)&&!journey.paused)showPause(true);}addEventListener('blur',blur);document.addEventListener('visibilitychange',()=>{if(document.hidden)blur();});
addEventListener('resize',()=>{renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();updateCamera(1,true);});
function updateUI(){
 const {phase}=journey,n=NODE[journey.at],choice=journey.choice,dest=choice&&NODE[choice.to];
 document.body.classList.toggle('intro',phase==='intro');document.body.classList.toggle('survey',journey.survey);document.body.classList.toggle('ended',phase==='arrival');
 $('#intro').hidden=phase!=='intro';$('#ending').hidden=phase!=='arrival';$('#menu').hidden=!journey.paused;
 $('#decision').hidden=phase!=='choice'||journey.paused;$('#travel').hidden=phase!=='walking'||journey.paused;$('#fuel').hidden=phase==='intro'||phase==='arrival';$('#map-key').hidden=!journey.survey||journey.paused;
 $('#survey').textContent=journey.survey?'↑ Return':'↑ Survey';$('#survey').setAttribute('aria-pressed',String(journey.survey));
 $('#pause').textContent=journey.paused?'Paused':phase==='walking'?'OK Pause':'↓ Options';$('#place').textContent=n.chapter;$('#chapter-number').textContent=journey.at==='field'?'01 / THE FIELDS':journey.at==='goal'?'03 / ARRIVAL':'02 / THE VILLAGE';
 $('#place-note').textContent=n.note;$('#light-value').textContent=`${Math.floor(journey.light)} / ${CAPACITY}`;
 [...$('#light-bars').children].forEach((el,i)=>{el.className=i>=Math.ceil(journey.light)?'empty':phase==='choice'&&i>=journey.light-(choice?.cost||0)?'spent':'';});
 if(choice){$('#lane-name').textContent=`${choice.name} · ${journey.selected+1} / ${journey.options.length}`;$('#destination').textContent=dest.name;$('#cost').textContent=`${choice.cost} light to walk · ${choice.cost>journey.light?'not enough light':`${Math.floor(journey.light-choice.cost)} left on arrival`}${dest.fire?' · flame refills here':''}`;$('#commit').classList.toggle('blocked',choice.cost>journey.light);$('#commit').setAttribute('aria-label',`${dest.name}. ${$('#cost').textContent}. Press OK to walk.`);}
 $('#message').textContent=journey.message;$('#travel-name').textContent=journey.travel?`To ${NODE[journey.travel.to].name}`:'';
 $('#ending-detail').textContent=`${Math.round(journey.distance)} metres through the night. ${journey.visited.size} places discovered. Take a moment here.`;
 $('#footer-note').textContent=phase==='arrival'?'Star, route and lantern challenge are creative adaptations.':'A story of arrival · Inspired by Luke 2:8–20';
 if(phase!==oldPhase){if(phase==='choice'&&n.fire)ding();if(phase==='arrival')speak($('#ending>p').textContent);oldPhase=phase;}
 if(phase==='choice'&&spoken!==journey.at){spoken=journey.at;if(journey.at!=='field')speak(n.note);}
}
function updateCamera(dt,instant=false){
 const p=journey.position;const aspect=camera.aspect;
 if(journey.survey){camTarget.set(9,aspect<1?139:88,aspect<1?108:70);lookTarget.set(0,0,3);}
 else if(journey.phase==='intro'){camTarget.set(-7,6.8,57);lookTarget.set(1,3,8);}
 else if(journey.phase==='arrival'){camTarget.set(-4,4,-34);lookTarget.set(3,1.4,-46);}
 else{
  // Fixed northward screen bearing: choosing and walking never turn the camera with heading.
  const preview=journey.phase==='choice'?NODE[journey.choice?.to]:null;
  const span=preview?Math.hypot(preview.x-p.x,preview.z-p.z):0;
  const cx=preview?(p.x+preview.x)/2:p.x,cz=preview?(p.z+preview.z)/2:p.z;
  camTarget.set(cx+9,preview?Math.max(10.8,span*.42):6.2,cz+(aspect<1?Math.max(30,span*1.35):preview?Math.max(24,span*.95):18));lookTarget.set(cx,1.2,cz-(preview?0:4));
 }
 const alpha=instant||reduced?1:1-Math.exp(-2.2*dt);camera.position.lerp(camTarget,alpha);look.lerp(lookTarget,alpha);camera.lookAt(look);
}
const v=new THREE.Vector3();
function updateLabels(){
 const p=journey.position;for(const entry of labelEntries){
  const visible=!journey.paused&&journey.phase!=='intro'&&journey.phase!=='arrival'&&(journey.survey||(!entry.edge&&!entry.player&&(entry.node===journey.choice?.to&&journey.phase==='choice')));
  entry.el.hidden=!visible;if(!visible)continue;
  const pt=entry.player?{...p,y:3.5}:entry.p;v.set(pt.x,height(pt.x,pt.z)+pt.y,pt.z).project(camera);
  entry.el.hidden=v.z>1||v.z< -1||Math.abs(v.x)>1||Math.abs(v.y)>1;if(entry.el.hidden)continue;
  entry.el.style.left=`${(v.x*.5+.5)*innerWidth}px`;entry.el.style.top=`${(-v.y*.5+.5)*innerHeight}px`;
  if(entry.node)entry.el.textContent=(entry.node===journey.at?'You · ':NODE[entry.node].fire?'● ':entry.node==='goal'?'◇ ':'')+NODE[entry.node].name;
  entry.el.classList.toggle('selected',entry.edge===journey.choice?.id||entry.node===journey.choice?.to);
 }
}
function animate(time){
 requestAnimationFrame(animate);const dt=Math.min((time-last)/1000||.016,.05);last=time;if(!ready)return;
 const active=!journey.paused,oldDistance=journey.distance;if(active)clock+=dt;journey.step(dt);
 const p=journey.position,movement=(journey.distance-oldDistance)/dt;
 if(p.heading!==undefined)desiredHeading=p.heading;
 heading+=Math.atan2(Math.sin(desiredHeading-heading),Math.cos(desiredHeading-heading))*(1-Math.exp(-8*dt));avatar.position.set(p.x,height(p.x,p.z)+.015,p.z);avatar.rotation.y=heading;
 characters.update(active?dt:0,{controller:{phase:journey.phase,gait:'walk'},movement,gaitBlend:0,paused:journey.paused||journey.phase!=='walking'});
 scene.fog.density=journey.survey?.0025:.008;world.update(active?dt:0,clock,journey);updateCamera(dt);updateLabels();
 const next=[journey.phase,journey.at,journey.selected,journey.paused,journey.survey,Math.floor(journey.light),journey.message].join('|');if(next!==signature){signature=next;updateUI();}
 renderer.render(scene,camera);
}
try{
 const loader=new GLTFLoader();await Promise.all([characters.load(loader),world.dress(loader)]);ready=true;$('#loading').hidden=true;console.info('Journey geometry: '+JSON.stringify({models:world.modelCount,minimumPathClearance:Math.min(...world.fits.map(f=>f.clearance)),fits:world.fits}));
 updateUI();updateCamera(1,true);window.lanternJourney={getState:()=>({...journey.snapshot(),models:world.modelCount,drawCalls:renderer.info.render.calls,survey:journey.survey}),command:input};
 requestAnimationFrame(animate);
}catch(e){console.error(e);$('#loading-text').textContent=`Could not load the study: ${e.message}. Check the local server and model files.`;}
