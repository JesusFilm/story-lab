import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Journey,NODE,NODES,EDGES,links,CAPACITY,lanePoints} from '../src/journey-model.mjs';
let checks=0;const check=(fn)=>{fn();checks++;};
const walk=(j,to)=>{const edge=j.options.find(e=>e.to===to);assert(edge,`missing ${j.at} -> ${to}`);assert(j.commit(edge),`blocked ${j.at} -> ${to}`);for(let i=0;i<2000&&j.travel;i++)j.step(.05);assert.equal(j.at,to);};
check(()=>{assert.equal(new Set(NODES.map(n=>n.id)).size,NODES.length);for(const e of EDGES){assert(NODE[e.a]&&NODE[e.b]);assert(e.cost>0&&e.cost<=CAPACITY);assert.equal(links(e.a).find(l=>l.id===e.id).to,e.b);}});
check(()=>{const j=new Journey();j.start();const before=j.snapshot();for(let i=0;i<1000;i++)j.step(1);assert.deepEqual(j.snapshot(),before);j.select(1);assert.equal(j.at,'field');assert.equal(j.distance,0);});
check(()=>{const j=new Journey();assert.equal(j.commit(),false);j.start();j.commit();assert.equal(j.commit(),false);j.step(1);j.paused=true;const state=j.snapshot();j.step(100);assert.deepEqual(j.snapshot(),state);j.paused=false;j.step(100);assert.equal(j.at,'gate');assert.equal(j.light,9);});
check(()=>{const j=new Journey();j.start();walk(j,'gate');const before=j.snapshot();assert.equal(j.commit(j.options.find(e=>e.to==='ridge')),false);assert.deepEqual(j.snapshot(),before);assert.match(j.message,/Not enough/);});
const routes=[['gate','olive','market','arch','goal'],['gate','well','square','arch','goal'],['gate','olive','market','square','arch','goal']];
const results=[];for(const route of routes)check(()=>{const j=new Journey();j.start();for(const to of route)walk(j,to);assert.equal(j.phase,'arrival');assert(j.light>=0);results.push({route:['field',...route],distance:Math.round(j.distance),light:j.light});});
check(()=>{const j=new Journey();j.start();walk(j,'gate');walk(j,'olive');walk(j,'lookout');assert.equal(j.light,5);assert.equal(j.back(),false);assert(j.recover());assert.equal(j.at,'olive');assert.equal(j.light,CAPACITY);assert(j.visited.has('lookout'));});
check(()=>{const j=new Journey();j.start();walk(j,'gate');walk(j,'well');assert(j.back()===false);j.commit(j.options.find(e=>e.to==='square'));j.step(.5);assert(j.recover());assert.equal(j.phase,'choice');assert.equal(j.at,'field');assert.equal(j.travel,null);j.reset();assert.deepEqual(j.snapshot(),new Journey().snapshot());});
// Exhaust every reachable (location, light, checkpoint) state. Every one can recover,
// and each checkpoint has a route to the ending without recovery or hidden assistance.
const queue=[['field',12,'field']],seen=new Set(),checkpoints=new Set();
while(queue.length){const [at,light,cp]=queue.shift(),key=`${at}:${light}:${cp}`;if(seen.has(key))continue;seen.add(key);checkpoints.add(cp);for(const e of links(at)){if(e.cost>light)continue;const n=NODE[e.to];queue.push([e.to,n.fire?12:light-e.cost,n.fire?e.to:cp]);}}
for(const cp of checkpoints)check(()=>{const q=[[cp,12]],visited=new Set();let found=false;while(q.length){const [at,fuel]=q.shift(),key=at+':'+fuel;if(visited.has(key))continue;visited.add(key);if(at==='goal'){found=true;break;}for(const e of links(at))if(e.cost<=fuel)q.push([e.to,NODE[e.to].fire?12:fuel-e.cost]);}assert(found,`${cp} has no completion`);});
check(()=>{for(const e of EDGES){const points=lanePoints(e);assert.equal(points[0].x,NODE[e.a].x);assert(Math.abs(points.at(-1).z-NODE[e.b].z)<1e-8);for(const p of points)assert(Number.isFinite(p.x)&&Number.isFinite(p.z));}});
const report={status:'passed',checks,reachableResourceStates:seen.size,checkpoints:[...checkpoints],routes:results,limits:'Logic verification establishes reachability and input state safety; not fun, visual quality, or TV performance.'};
writeFileSync(new URL('./journey-verification.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
