import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {JourneyCamera,routeLookahead,blocked,angleDelta} from '../src/journey-camera.mjs';
import {EDGES,lanePoints} from '../src/journey-model.mjs';
import {height} from '../src/journey-terrain.mjs';
const evidence=new URL('../review/2026-09-10-search-and-camera/scene-geometry.json',import.meta.url);
const {occluders:boxes}=JSON.parse(readFileSync(evidence));
let frames=0,hidden=0,aheadHidden=0,minimumArm=100,yawChanges=0;const failures=[];
for(const portrait of [false,true])for(const reverseStart of [false,true])for(const e of EDGES)for(const reverse of [false,true]){
 const points=reverse?lanePoints(e).reverse():lanePoints(e),lengths=points.slice(1).map((p,i)=>Math.hypot(p.x-points[i].x,p.z-points[i].z));const length=lengths.reduce((a,b)=>a+b,0),rig=new JourneyCamera();let previousYaw;
 for(let d=0;d<length;d+=2.8/30){
  const travel={points,lengths,length,progress:d},p=routeLookahead(travel,0),ahead=routeLookahead(travel,3.5),heading=Math.atan2(ahead.x-p.x,ahead.z-p.z);
  if(d===0&&reverseStart)rig.yaw=heading+Math.PI;
  const f=rig.update({player:{...p,y:height(p.x,p.z)},heading,ahead,boxes,dt:1/30,portrait,instant:d===0&&!reverseStart});frames++;
  if(!f.playerVisible){hidden++;if(failures.length<8)failures.push({edge:e.id,reverse,d,portrait});}
  if(!f.aheadVisible)aheadHidden++;minimumArm=Math.min(minimumArm,f.arm);if(previousYaw!==undefined)yawChanges=Math.max(yawChanges,Math.abs(angleDelta(previousYaw,f.yaw)));previousYaw=f.yaw;
  assert(Number.isFinite(f.position.x)&&Number.isFinite(f.look.y));
 }
}
const report={status:hidden?'failed':'passed',directedLaneConfigurations:EDGES.length*8,frames,hiddenPlayerChestFrames:hidden,aheadOcclusionFrames:aheadHidden,minimumArmMetres:minimumArm,maxYawStepRadians:yawChanges,failures,limits:'Sampled character-chest visibility against loaded structure bounds. Does not prove full-body visibility, tree/prop occlusion, inspection-camera composition, or subjective motion quality.'};
writeFileSync(new URL('./journey-camera-verification.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));assert.equal(hidden,0);
