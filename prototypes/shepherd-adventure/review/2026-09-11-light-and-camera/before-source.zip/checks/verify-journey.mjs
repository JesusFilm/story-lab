import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Journey,NODE,NODES,EDGES,OBSERVATIONS,links,lanePoints} from '../src/journey-model.mjs';
let checks=0;const check=fn=>{fn();checks++;};
function walk(j,to){const e=j.options.find(e=>e.to===to);assert(e,`unavailable ${j.at} -> ${to}`);assert(j.commit(e));assert.equal(j.phase,'walking');for(let i=0;i<2000&&j.travel;i++)j.step(.05);assert.equal(j.at,to);}
function inspect(j){assert(j.inspect());if(j.phase!=='arrival')assert(j.closeInspection());}
check(()=>{assert.equal(new Set(NODES.map(n=>n.id)).size,NODES.length);for(const e of EDGES){assert(NODE[e.a]&&NODE[e.b]);assert(!('cost' in e));assert.equal(links(e.a).find(x=>x.id===e.id).to,e.b);}});
check(()=>{const j=new Journey();j.start();const before=j.snapshot();j.step(100);assert.deepEqual(j.snapshot(),before);j.select(1);assert.equal(j.distance,0);assert.equal(j.at,'field');assert.equal(j.discoveries.size,0);});
check(()=>{const j=new Journey();j.start();j.commit();assert.equal(j.commit(),false);j.step(1);j.paused=true;const before=j.snapshot();j.step(100);assert.deepEqual(j.snapshot(),before);j.paused=false;j.step(100);assert.equal(j.at,'gate');});
check(()=>{const j=new Journey();j.start();walk(j,'gate');walk(j,'olive');walk(j,'market');const at=j.at,d=j.distance;assert(j.commit(j.options.find(e=>e.to==='arch')));assert.equal(j.phase,'inspect');assert.equal(j.at,at);assert.equal(j.distance,d);assert(!j.gateOpen);assert.match(j.inspection.body,/far side|cannot be opened/);j.closeInspection();walk(j,'square');assert(!j.options.some(e=>e.to==='arch'));});
const routes=[];
check(()=>{const j=new Journey();j.start();for(const to of ['gate','well','square','pen'])walk(j,to);assert(!j.options.some(e=>e.to==='arch'));inspect(j);assert(j.discoveries.has('rear'));assert.equal(j.phase,'choice');walk(j,'arch');inspect(j);assert(j.gateOpen);walk(j,'goal');assert.equal(j.phase,'choice','walking alone must not complete the investigation');inspect(j);assert.equal(j.phase,'arrival');routes.push({route:'animal-fold discovery',metres:Math.round(j.distance),discoveries:[...j.discoveries]});});
check(()=>{const j=new Journey();j.start();for(const to of ['gate','olive','lookout'])walk(j,to);inspect(j);assert(j.discoveries.has('overlook'));for(const to of ['olive','market','square','arch','goal'])walk(j,to);inspect(j);assert.equal(j.phase,'arrival');routes.push({route:'overlook discovery',metres:Math.round(j.distance),discoveries:[...j.discoveries]});});
check(()=>{const j=new Journey();j.start();for(const to of ['gate','ridge','pen'])walk(j,to);inspect(j);walk(j,'arch');inspect(j);walk(j,'market');assert(j.gateOpen);assert(j.recover());assert.equal(j.at,'gate');assert(j.visited.has('pen'));assert(j.discoveries.has('rear'));assert(j.inspected.has('pen'));j.reset();assert.deepEqual(j.snapshot(),new Journey().snapshot());});
check(()=>{const j=new Journey();j.start();inspect(j);const before=j.snapshot();inspect(j);assert.deepEqual(j.snapshot(),before);assert.equal(j.commit({id:'invented',to:'goal'}),false);});
// Independent reachability over location + persistent knowledge. Gate and hidden-lane
// requirements are checked separately from the controller implementation.
function successors(at,knowledge){const states=[];const clue=OBSERVATIONS[at].unlock;if(clue&&!knowledge.includes(clue))states.push([at,[...knowledge,clue].sort()]);for(const e of links(at))if(!e.requires||knowledge.includes(e.requires))states.push([e.to,knowledge]);return states;}
function explore(start){const q=[start],seen=new Map();while(q.length){const [at,k]=q.shift(),key=at+':'+k.join(',');if(seen.has(key))continue;seen.set(key,[at,k]);if(at==='goal')continue;q.push(...successors(at,k));}return seen;}
const states=explore(['field',[]]);
check(()=>{for(const state of states.values())assert([...explore(state).values()].some(([at])=>at==='goal'),`softlock: ${state}`);});
check(()=>{for(const e of EDGES){const points=lanePoints(e);assert.equal(points[0].x,NODE[e.a].x);assert(Math.abs(points.at(-1).z-NODE[e.b].z)<1e-8);for(const p of points)assert(Number.isFinite(p.x)&&Number.isFinite(p.z));}});
const report={status:'passed',checks,knowledgeStates:states.size,routes,limits:'Reachability and state safety do not establish an enjoyable investigation. Scene clues and camera need visual playtest.'};writeFileSync(new URL('./journey-verification.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
