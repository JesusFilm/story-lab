import {JourneyCamera,routeLookahead} from './journey-camera.mjs';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {CharacterVariants} from './character-variants.mjs';
import {Journey,NODE,NODES,EDGES,OBSERVATIONS} from './journey-model.mjs';
import {createJourneyWorld,height} from './journey-world.mjs';

const $=s=>document.querySelector(s),journey=new Journey();
const renderer=new THREE.WebGLRenderer({canvas:$('#world'),antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
const scene=new THREE.Scene();scene.background=new THREE.Color('#020409');scene.fog=new THREE.Fog('#020409',14,48);
const cameraRig=new JourneyCamera();
const camera=new THREE.PerspectiveCamera(54,innerWidth/innerHeight,.1,500);
scene.add(new THREE.HemisphereLight('#91b6dd','#101015',.13));
const moon=new THREE.DirectionalLight('#93b7e9',.20);moon.position.set(-35,50,25);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);Object.assign(moon.shadow.camera,{left:-55,right:55,top:65,bottom:-65,near:1,far:160});moon.shadow.normalBias=.06;moon.shadow.bias=-.0003;scene.add(moon,moon.target);
const world=createJourneyWorld(scene),avatar=new THREE.Group();scene.add(avatar);const characters=new CharacterVariants(avatar);
let ready=false,last=0,clock=0,signature='',oldPhase='intro',menuIndex=0,heading=Math.PI,desiredHeading=Math.PI,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const held=new Set(),camTarget=new THREE.Vector3(),lookTarget=new THREE.Vector3(),look=new THREE.Vector3();
let audioContext,audioGain,sound=false,spoken='';
function speak(text){if(!sound||!('speechSynthesis' in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.87;u.volume=.85;speechSynthesis.speak(u);}
async function toggleSound(){
 sound=!sound;$('#sound').textContent=sound?'Sound on':'Sound off';$('#sound').setAttribute('aria-pressed',String(sound));
 if(sound){try{if(!audioContext){audioContext=new AudioContext();audioGain=audioContext.createGain();audioGain.gain.value=.026;audioGain.connect(audioContext.destination);
  for(const f of [146.83,220,293.66]){const o=audioContext.createOscillator();o.type='sine';o.frequency.value=f;const g=audioContext.createGain();g.gain.value=.14;o.connect(g);g.connect(audioGain);o.start();}
  const buffer=audioContext.createBuffer(1,audioContext.sampleRate*3,audioContext.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;const noise=audioContext.createBufferSource();noise.buffer=buffer;noise.loop=true;const filter=audioContext.createBiquadFilter();filter.type='lowpass';filter.frequency.value=340;noise.connect(filter);filter.connect(audioGain);noise.start();
 }await audioContext.resume();speak(journey.phase==='intro'?$('#intro>p').textContent:journey.phase==='arrival'?$('#ending>p').textContent:NODE[journey.at].note);}catch{sound=false;$('#sound').textContent='Sound unavailable';}}
 else{audioContext?.suspend();if('speechSynthesis' in window)speechSynthesis.cancel();}
}
function ding(){if(!sound||!audioContext)return;const o=audioContext.createOscillator(),g=audioContext.createGain();o.frequency.value=587.33;o.type='sine';o.connect(g);g.connect(audioContext.destination);g.gain.setValueAtTime(.045,audioContext.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+1.8);o.start();o.stop(audioContext.currentTime+1.8);}
function reset(){cameraRig.reset();journey.reset();signature='';oldPhase='intro';heading=desiredHeading=Math.PI;spoken='';if('speechSynthesis' in window)speechSynthesis.cancel();updateUI();updateCamera(1,true);}
function begin(){if(!ready)return;journey.start();updateUI();}
const menuButtons=[$('#resume'),$('#back'),$('#remember'),$('#recover'),$('#restart')];
function showPause(value){if(!ready||!['choice','walking','inspect'].includes(journey.phase))return;journey.paused=value;menuIndex=0;$('#back').disabled=journey.phase!=='choice'||!journey.previous;focusMenu();if('speechSynthesis' in window){if(value)speechSynthesis.pause();else speechSynthesis.resume();}updateUI();}
function focusMenu(){menuButtons.forEach((b,i)=>b.classList.toggle('selected',i===menuIndex));if(journey.paused)menuButtons[menuIndex].focus({preventScroll:true});else document.activeElement?.blur();}
function recover(){journey.recover();document.activeElement?.blur();updateUI();updateCamera(1,true);}
function input(key){
 if(!ready)return;
 if(journey.phase==='intro'){if(['Enter',' ','Select'].includes(key))begin();else if(key==='ArrowUp')toggleSound();return;}
 if(journey.phase==='arrival'){if(['Enter',' ','Select'].includes(key))reset();return;}
 if(journey.notebook){if(['Enter',' ','Select','Escape'].includes(key)){journey.notebook=false;updateUI();}else if(key==='ArrowUp'||key==='ArrowDown')$('#notes').scrollBy({top:key==='ArrowDown'?120:-120,behavior:reduced?'auto':'smooth'});return;}
 if(journey.paused){if(key==='ArrowDown'||key==='ArrowUp'){do{menuIndex=(menuIndex+(key==='ArrowUp'?-1:1)+menuButtons.length)%menuButtons.length;}while(menuButtons[menuIndex].disabled);focusMenu();}else if(['Enter',' ','Select'].includes(key))menuButtons[menuIndex].click();else if(key==='Escape')showPause(false);return;}
 if(key==='ArrowDown'||key==='Escape'||key==='p'||key==='P'){showPause(true);return;}
 if(journey.phase==='inspect'){
  if(key==='ArrowLeft'||key==='ArrowRight')journey.inspectionYaw=THREE.MathUtils.clamp(journey.inspectionYaw+(key==='ArrowLeft'?-.35:.35),-1.4,1.4);
  else if(['Enter',' ','Select','ArrowUp'].includes(key))journey.closeInspection();updateUI();return;
 }
 if(journey.phase==='walking'){if(['Enter',' ','Select'].includes(key))showPause(true);return;}
 if(key==='ArrowUp'){journey.inspect();updateUI();return;}
 if(key==='ArrowLeft')journey.select(-1);else if(key==='ArrowRight')journey.select(1);else if(['Enter',' ','Select'].includes(key))journey.commit();updateUI();
}
function remember(){journey.paused=false;journey.notebook=true;document.activeElement?.blur();updateUI();}
$('#begin').onclick=begin;$('#prev').onclick=()=>input('ArrowLeft');$('#next').onclick=()=>input('ArrowRight');$('#commit').onclick=()=>input('Enter');$('#survey').onclick=()=>input('ArrowUp');$('#pause').onclick=()=>showPause(true);$('#resume').onclick=()=>showPause(false);$('#back').onclick=()=>{showPause(false);journey.back();updateUI();};$('#remember').onclick=remember;$('#recover').onclick=recover;$('#restart').onclick=reset;$('#again').onclick=reset;$('#sound').onclick=toggleSound;$('#inspect-close').onclick=()=>input('Enter');$('#notes-close').onclick=()=>input('Enter');
addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter',' ','Select','Escape','p','P'].includes(e.key)){e.preventDefault();if(e.repeat||held.has(e.key))return;held.add(e.key);input(e.key);}});addEventListener('keyup',e=>held.delete(e.key));
function blur(){held.clear();if(['choice','walking'].includes(journey.phase)&&!journey.paused&&!journey.notebook)showPause(true);}addEventListener('blur',blur);document.addEventListener('visibilitychange',()=>{if(document.hidden)blur();});
addEventListener('resize',()=>{renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();updateCamera(1,true);});
function drawNotebook(){
 const xy=n=>({x:28+(n.x+32)/60*264,y:20+(n.z+43)/79*228});
 const knownEdges=EDGES.filter(e=>journey.traversed.has(e.id)||(e.requires&&journey.discoveries.has(e.requires)));
 const known=new Set(journey.visited);for(const e of knownEdges){known.add(e.a);known.add(e.b);}
 let svg='';for(const e of knownEdges){const a=xy(NODE[e.a]),b=xy(NODE[e.b]);svg+=`<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#81775f" stroke-width="1.5" ${journey.traversed.has(e.id)?'':'stroke-dasharray="3 3"'}/>`;}
 for(const id of known){const n=NODE[id],p=xy(n);svg+=`<circle cx="${p.x}" cy="${p.y}" r="${id===journey.at?5:3}" fill="${id===journey.at?'#ade1d0':'#c7ac72'}"/><text x="${p.x}" y="${p.y-8}" text-anchor="middle">${n.name.replace('The ','').replace('the ','')}</text>`;}
 $('#memory-map').innerHTML=svg;
 $('#observations').replaceChildren();for(const id of journey.inspected){const el=document.createElement('p'),title=document.createElement('b');title.textContent=OBSERVATIONS[id].title;el.append(title,document.createElement('br'),OBSERVATIONS[id].body);$('#observations').append(el);}
 if(!journey.inspected.size)$('#observations').textContent='No observations yet. Raise your lantern with ↑ when you stop somewhere.';
}
function updateUI(){
 const {phase}=journey,n=NODE[journey.at],choice=journey.choice,dest=choice&&NODE[choice.to];
 document.body.classList.toggle('intro',phase==='intro');document.body.classList.remove('survey');document.body.classList.toggle('ended',phase==='arrival');document.body.classList.toggle('inspecting',phase==='inspect');
 $('#intro').hidden=phase!=='intro';$('#ending').hidden=phase!=='arrival';$('#menu').hidden=!journey.paused;
 $('#decision').hidden=phase!=='choice'||journey.paused||journey.notebook;$('#travel').hidden=phase!=='walking'||journey.paused||journey.notebook;$('#fuel').hidden=['intro','arrival','inspect'].includes(phase);$('#notes').hidden=!journey.notebook;
 $('#inspection').hidden=phase!=='inspect'||journey.paused||journey.notebook;
 if(journey.inspection){$('#inspect-title').textContent=journey.inspection.title;$('#inspect-copy').textContent=journey.inspection.body;$('#inspect-tag').textContent=journey.inspection.unlock?'A USEFUL DISCOVERY':'LOOK CLOSELY';}
 $('#survey').textContent=phase==='inspect'?'↑ Return':'↑ Investigate';$('#survey').disabled=phase==='walking';$('#survey').setAttribute('aria-pressed',String(phase==='inspect'));
 $('#pause').textContent=journey.paused?'Paused':phase==='walking'?'OK Pause':'↓ Options';$('#place').textContent=n.chapter;$('#chapter-number').textContent=journey.at==='field'?'01 / THE FIELDS':journey.at==='goal'?'03 / THE SHELTER':'02 / THE SEARCH';
 $('#place-note').textContent=n.note;
 if(choice){const known=journey.visited.has(choice.to);$('#lane-name').textContent=`${journey.selected+1} / ${journey.options.length} PATHS`;$('#destination').textContent=known?dest.name:choice.name;$('#cost').textContent=choice.requires==='gate'&&!journey.gateOpen?'A gate across the lane · OK Examine':known?'A place you remember · OK Walk':'Beyond the next bend · OK Explore';$('#commit').classList.remove('blocked');$('#commit').setAttribute('aria-label',`${$('#destination').textContent}. ${$('#cost').textContent}.`);}
 $('#message').textContent=journey.message;$('#travel-name').textContent=journey.travel?(journey.visited.has(journey.travel.to)?`Back to ${NODE[journey.travel.to].name}`:'Into the next lane…'):'';
 $('#choice-help').textContent='← → Choose · OK Walk · ↑ Investigate · ↓ Options';
 $('#ending-detail').textContent=`${Math.round(journey.distance)} metres through the night. ${journey.inspected.size} places investigated. Take a moment here.`;
 $('#footer-note').textContent=phase==='arrival'?'Route, clues and village details are creative adaptations.':'A story of arrival · Inspired by Luke 2:8–20';
 if(phase!==oldPhase){if(phase==='inspect'){speak(journey.inspection.body);if(journey.inspection.unlock)ding();}if(phase==='arrival')speak($('#ending>p').textContent);oldPhase=phase;}
 if(journey.notebook)drawNotebook();
}
function updateCamera(dt,instant=false){
 const p=journey.position;const aspect=camera.aspect;
 if(journey.notebook)return;
 if(journey.phase==='intro'){camTarget.set(-7,6.8,57);lookTarget.set(1,3,8);}
 else if(journey.phase==='arrival'){camTarget.set(-4,4,-34);lookTarget.set(3,1.4,-46);}
 else if(journey.phase==='inspect'){
  const target=world.clueTargets[journey.at]||{x:p.x,y:1,z:p.z};
  if(journey.at==='lookout'){camTarget.set(p.x+Math.sin(journey.inspectionYaw)*3,height(p.x,p.z)+16,p.z+3);lookTarget.set(target.x,target.y-3,target.z);const a=instant?1:1-Math.exp(-3*dt);camera.position.lerp(camTarget,a);look.lerp(lookTarget,a);camera.lookAt(look);return;}
  const inspectionHeading=Math.atan2(target.x-p.x,target.z-p.z)+journey.inspectionYaw;
  const frame=cameraRig.update({player:{x:target.x,y:target.y-1.1,z:target.z},heading:inspectionHeading,ahead:target,boxes:world.occluders,dt,instant:instant||reduced,portrait:aspect<1});
  camera.position.set(frame.position.x,frame.position.y,frame.position.z);look.set(target.x,target.y,target.z);camera.lookAt(look);return;
 }
 else{
  const preview=journey.phase==='choice'?NODE[journey.choice?.to]:null;
  const ahead=routeLookahead(journey.travel)||preview;
  const direction=ahead?Math.atan2(ahead.x-p.x,ahead.z-p.z):heading;
  const frame=cameraRig.update({player:{...p,y:height(p.x,p.z)},heading:direction,ahead,boxes:world.occluders,dt,instant:instant||reduced,portrait:aspect<1});
  camera.position.set(frame.position.x,frame.position.y,frame.position.z);look.set(frame.look.x,frame.look.y,frame.look.z);camera.lookAt(look);return;
 }
 const alpha=instant||reduced?1:1-Math.exp(-2.2*dt);camera.position.lerp(camTarget,alpha);look.lerp(lookTarget,alpha);camera.lookAt(look);
}
function animate(time){
 requestAnimationFrame(animate);const dt=Math.min((time-last)/1000||.016,.05);last=time;if(!ready)return;
 const active=!journey.paused&&!journey.notebook,oldDistance=journey.distance;if(active){clock+=dt;journey.step(dt);}
 const p=journey.position,movement=(journey.distance-oldDistance)/dt;
 if(p.heading!==undefined)desiredHeading=p.heading;
 heading+=Math.atan2(Math.sin(desiredHeading-heading),Math.cos(desiredHeading-heading))*(1-Math.exp(-8*dt));avatar.position.set(p.x,height(p.x,p.z)+.015,p.z);avatar.rotation.y=heading;
 characters.update(active?dt:0,{controller:{phase:journey.phase,gait:'walk'},movement,gaitBlend:0,paused:journey.paused||journey.phase!=='walking'});
 world.update(active?dt:0,clock,journey);updateCamera(dt);
 const next=[journey.phase,journey.at,journey.selected,journey.paused,journey.notebook,journey.inspected.size,journey.message].join('|');if(next!==signature){signature=next;updateUI();}
 renderer.render(scene,camera);
}
try{
 const loader=new GLTFLoader();await Promise.all([characters.load(loader),world.dress(loader)]);ready=true;$('#loading').hidden=true;console.info('Journey geometry: '+JSON.stringify({models:world.modelCount,minimumPathClearance:Math.min(...world.fits.map(f=>f.clearance)),fits:world.fits,occluders:world.occluders}));
 updateUI();updateCamera(1,true);window.lanternJourney={getState:()=>({...journey.snapshot(),models:world.modelCount,drawCalls:renderer.info.render.calls,camera:cameraRig.lastDiagnostics}),command:input};
 requestAnimationFrame(animate);
}catch(e){console.error(e);$('#loading-text').textContent=`Could not load the study: ${e.message}. Check the local server and model files.`;}
