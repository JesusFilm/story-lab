// An authored investigation: knowledge opens routes; light has no resource cost.
export const NODES=[
 {id:'field',name:'The shepherd’s field',x:0,z:36,fire:true,chapter:'Outside Bethlehem',note:'A baby lying in a manger. Somewhere beyond these few lights.'},
 {id:'gate',name:'The village threshold',x:0,z:20,chapter:'At the threshold',note:'Several lanes disappear between the houses. What is worth following?'},
 {id:'olive',name:'Olive courtyard',x:-15,z:7,fire:true,chapter:'Among the first houses',note:'Baking embers, closed doors, and a path rising above the roofs.'},
 {id:'well',name:'The old well',x:13,z:7,chapter:'At the old well',note:'The ground is softer here. Your lantern catches marks in the mud.'},
 {id:'market',name:'Sleeping market',x:-18,z:-9,chapter:'The sleeping market',note:'A lane through the stalls. A gate across the way beyond.'},
 {id:'square',name:'Lantern courtyard',x:3,z:-11,fire:true,chapter:'The quiet courtyard',note:'Animal tracks leave the pool of light. Low roofs lie beyond the wall.'},
 {id:'ridge',name:'The exposed ridge',x:28,z:-5,chapter:'Above the rooftops',note:'A quicker-looking path skirts the houses. Its far end disappears into darkness.'},
 {id:'lookout',name:'The hillside overlook',x:-32,z:-4,chapter:'Above the sleeping village',note:'The climb offers a different view of the lanes below.'},
 {id:'arch',name:'The rear passage',x:-8,z:-26,fire:true,chapter:'Behind the last houses',note:'You have come around the wall. A quiet shelter lies beyond the passage.'},
 {id:'pen',name:'The animal fold',x:18,z:-25,chapter:'At the animal fold',note:'Animals, straw and a trough. This could be a place to look.'},
 {id:'goal',name:'The open shelter',x:3,z:-43,chapter:'At a quiet shelter',note:'Lamplight under a low roof. Look inside.'}
];
export const EDGES=[
 ['field','gate','A lane toward the village'],['gate','olive','Lamplight among the trees'],['gate','well','A worn stone lane'],['gate','ridge','A footpath into the wind'],
 ['olive','market','Between shuttered houses'],['olive','lookout','A climb above the rooftops'],['well','square','Along the muddy lane'],
 ['well','ridge','Steps toward the hillside'],['market','square','Past the empty stalls'],['market','arch','The wooden gate','gate'],
 ['square','arch','The lane behind the low wall','overlook'],['square','pen','Animal tracks in the dust'],['square','ridge','Steps out of the courtyard'],
 ['ridge','pen','Down toward a low roof'],['arch','goal','A quiet light beyond the wall'],['pen','arch','The gap behind the feeding trough','rear']
].map(([a,b,name,requires],i)=>({id:`lane-${i}`,a,b,name,requires}));
export const NODE=Object.fromEntries(NODES.map(n=>[n.id,n]));
export function links(id){return EDGES.filter(e=>e.a===id||e.b===id).map(e=>({...e,to:e.a===id?e.b:e.a})).sort((a,b)=>NODE[a.to].x-NODE[b.to].x||NODE[a.to].z-NODE[b.to].z);}
export function lanePoints(edge){const a=NODE[edge.a],b=NODE[edge.b];const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz);return Array.from({length:25},(_,i)=>{const t=i/24,bend=Math.sin(t*Math.PI)*1.15;return {x:a.x+dx*t-dz/len*bend,z:a.z+dz*t+dx/len*bend};});}
export const OBSERVATIONS={
 field:{title:'Remember the sign',body:'The announcement spoke of a baby lying in a manger. Look for a place where animals are fed. A bright house alone is not enough.',kind:'lantern'},
 gate:{title:'The sleeping village',body:'Closed doorways to one side. A well-worn lane to the other. The path on the hill could be shorter, but you cannot see where it ends.',kind:'lantern'},
 olive:{title:'A household courtyard',body:'Bread ovens and shuttered rooms. No feeding trough here. The uphill path may let you see over the walls before committing to another lane.',kind:'tree'},
 well:{title:'Tracks by the water',body:'Small hoofprints leave the wet ground and continue into the courtyard. They are worth following, but animals alone will not tell you where the child is.',kind:'well'},
 market:{title:'A bar on the far side',body:'The gate cannot be opened from here. Beyond it, the lane continues behind the houses. You will need to find a way around; the courtyard is still reachable.',kind:'gate'},
 square:{title:'Two different signs',body:'Hoofprints leave toward the animal fold. Loose straw also catches beneath the low wall, but from here no opening is obvious. A higher viewpoint might help.',kind:'tracks'},
 ridge:{title:'A roof in the darkness',body:'The path descends toward an animal enclosure. It may be useful to investigate, but this view does not reveal whether anyone is sheltering there.',kind:'ridge'},
 lookout:{title:'A lane you could not see below',body:'From above, you can trace an overlooked lane behind the courtyard’s low wall. It reaches the far side of the market gate. You remember where to find its entrance.',kind:'vista',unlock:'overlook'},
 pen:{title:'Animals, but no family',body:'This is an ordinary fold. Behind the feeding trough, a gap in the wall leads into a rear passage. The detour has found you another way around the village.',kind:'trough',unlock:'rear'},
 arch:{title:'The gate opens from this side',body:'You lift the bar: the market route is now open for retracing. Beyond the passage, a small light shines beneath an open roof.',kind:'gate',unlock:'gate'},
 goal:{title:'The sign you were looking for',body:'A baby, wrapped and lying in a manger. You have found the place.',kind:'manger'}
};
export class Journey{
 constructor(){this.reset();}
 reset(){this.at='field';this.previous=null;this.travel=null;this.phase='intro';this.paused=false;this.selected=0;this.inspection=null;this.inspectionYaw=0;this.notebook=false;this.visited=new Set(['field']);this.inspected=new Set();this.discoveries=new Set();this.traversed=new Set();this.distance=0;this.recoveries=0;this.message='';this.decisions=0;}
 get options(){return links(this.at).filter(e=>!['overlook','rear'].includes(e.requires)||this.discoveries.has(e.requires)||this.traversed.has(e.id));}
 get choice(){return this.options[this.selected%this.options.length];}
 get gateOpen(){return this.discoveries.has('gate');}
 start(){if(this.phase!=='intro')return false;this.phase='choice';return true;}
 select(delta){if(this.phase!=='choice'||this.paused)return false;this.selected=(this.selected+delta+this.options.length)%this.options.length;this.message='';return true;}
 inspect(){
  if(this.phase!=='choice'||this.paused)return false;
  this.inspected.add(this.at);this.inspection={...OBSERVATIONS[this.at],node:this.at};this.inspectionYaw=0;
  if(this.inspection.unlock)this.discoveries.add(this.inspection.unlock);
  this.phase=this.at==='goal'?'arrival':'inspect';this.message='';return true;
 }
 closeInspection(){if(this.phase!=='inspect')return false;this.phase='choice';this.inspection=null;return true;}
 commit(edge=this.choice){
  if(this.phase!=='choice'||this.paused||!edge||!this.options.some(e=>e.id===edge.id&&e.to===edge.to))return false;
  if(edge.requires==='gate'&&!this.gateOpen){return this.inspect();}
  const raw=lanePoints(edge),points=edge.a===this.at?raw:raw.slice().reverse();
  const lengths=points.slice(1).map((p,i)=>Math.hypot(p.x-points[i].x,p.z-points[i].z));
  this.travel={edge,from:this.at,to:edge.to,points,lengths,length:lengths.reduce((a,b)=>a+b,0),progress:0};
  this.phase='walking';this.message='';this.decisions++;return true;
 }
 back(){return this.commit(this.options.find(e=>e.to===this.previous)||null);}
 recover(){if(!['choice','walking','inspect'].includes(this.phase))return false;this.at='gate';this.travel=null;this.inspection=null;this.phase='choice';this.paused=false;this.previous=null;this.selected=0;this.recoveries++;this.visited.add('gate');this.message='Back at the village threshold. You remember everything you found.';return true;}
 step(dt){
  if(this.phase!=='walking'||this.paused||!Number.isFinite(dt)||dt<=0)return;
  const t=this.travel,amount=Math.min(dt*2.8,t.length-t.progress);t.progress+=amount;this.distance+=amount;
  if(t.progress>=t.length-1e-8){this.previous=t.from;this.at=t.to;this.visited.add(this.at);this.traversed.add(t.edge.id);this.travel=null;this.phase='choice';this.selected=Math.max(0,this.options.findIndex(e=>e.to!==this.previous));}
 }
 get position(){
  if(!this.travel)return {...NODE[this.at]};
  let d=this.travel.progress;const {points,lengths}=this.travel;
  for(let i=0;i<lengths.length;i++){if(d<=lengths[i]){const f=d/lengths[i];return {x:points[i].x+(points[i+1].x-points[i].x)*f,z:points[i].z+(points[i+1].z-points[i].z)*f,heading:Math.atan2(points[i+1].x-points[i].x,points[i+1].z-points[i].z)};}d-=lengths[i];}return {...NODE[this.travel.to]};
 }
 snapshot(){return {at:this.at,phase:this.phase,paused:this.paused,selected:this.choice?.to,visited:[...this.visited],inspected:[...this.inspected],discoveries:[...this.discoveries],traversed:[...this.traversed],gateOpen:this.gateOpen,distance:this.distance,recoveries:this.recoveries,decisions:this.decisions,position:this.position};}
}
