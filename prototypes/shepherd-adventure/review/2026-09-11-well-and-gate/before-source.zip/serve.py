"""Local-only player. Dependency cache stays outside the shared workspace."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, unquote
import os, subprocess, tempfile, argparse, json

ROOT = Path(__file__).resolve().parent
MAP = ROOT.parents[2] / 'references/reference-pack-v1/storyline-1-shepherd/map/maze-layout.json'
TRIPO_SHEPHERD = ROOT.parents[2] / ('assets/characters/shepherd/styles/follow-the-light-aa/models/tripo/'
    'op-8c89d41a-5456-4f3a-818a-9f98177c45be/corrections/'
    'correction-fc020f44-6286-4f42-a72b-8796da5d99a1/model.glb')
TRIPO_LOW_WALL = ROOT.parents[2] / ('assets/structures/low-wall-kit/styles/follow-the-light-aa/models/tripo/'
    'op-e113637a-9620-4074-b651-3c3f8e80129a/mesh/op-e113637a-9620-4074-b651-3c3f8e80129a/model.glb')
TRIPO_HOUSE = ROOT.parents[2] / ('assets/structures/house-01/styles/follow-the-light-aa/models/tripo/'
    'op-d55ecb26-66e0-41b8-9650-47150094a87d/mesh/op-d55ecb26-66e0-41b8-9650-47150094a87d/model.glb')
TRIPO_MARKET = ROOT.parents[2] / ('assets/structures/market-stall/styles/follow-the-light-aa/models/tripo/'
    'op-7fff2a8a-7722-4a24-b499-29d43a6ad166/mesh/op-7fff2a8a-7722-4a24-b499-29d43a6ad166/model.glb')
TRIPO_ANIMAL_PEN = ROOT.parents[2] / ('assets/structures/animal-pen/styles/follow-the-light-aa/models/tripo/'
    'op-a9a775b9-f1cc-4f45-98e9-9b8ccc97f13e/mesh/op-a9a775b9-f1cc-4f45-98e9-9b8ccc97f13e/model.glb')
TRIPO_STRUCTURE_LAMP = ROOT.parents[2] / ('assets/objects/structure-lamp/styles/follow-the-light-aa/models/tripo/'
    'op-25c6c2d1-7e7a-452f-a83b-cf708dd6faa2/mesh/op-25c6c2d1-7e7a-452f-a83b-cf708dd6faa2/model.glb')
TRIPO_SHEEP = ROOT.parents[2] / ('assets/animals/sheep/styles/follow-the-light-aa/models/tripo/'
    'op-3d4579da-1294-414a-806a-37b2ddb9459b/corrections/'
    'correction-8c348481-eeaf-42b1-8cbf-bdf31b798bb4/model.glb')
CACHE = Path(os.environ.get('WATCH_GAME_RUNTIME', '/tmp/watch-game-blender-runtime'))
THREE = CACHE / 'node_modules/three'

def ensure_runtime():
    manifest = THREE / 'package.json'
    if not manifest.exists() or json.loads(manifest.read_text())['version'] != '0.169.0':
        print('Installing pinned Three.js 0.169.0 in temporary runtime cache...', flush=True)
        subprocess.run(['npm','install','--prefix',str(CACHE),'--no-audit','--no-fund',
                        '--no-package-lock','--ignore-scripts','three@0.169.0'],check=True)

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        path = unquote(urlsplit(path).path)
        if path == '/map/maze-layout.json': return str(MAP)
        if path == '/assets/shepherd-tripo-v2.glb': return str(TRIPO_SHEPHERD)
        if path == '/assets/low-wall-kit-tripo-v2.glb': return str(TRIPO_LOW_WALL)
        if path == '/assets/house-01-tripo-v2.glb': return str(TRIPO_HOUSE)
        if path == '/assets/market-stall-tripo-v2.glb': return str(TRIPO_MARKET)
        if path == '/assets/animal-pen-tripo-v2.glb': return str(TRIPO_ANIMAL_PEN)
        if path == '/assets/structure-lamp-tripo-v2.glb': return str(TRIPO_STRUCTURE_LAMP)
        if path == '/assets/sheep-tripo-v2.glb': return str(TRIPO_SHEEP)
        base = THREE if path.startswith('/vendor/three/') else ROOT
        rel = path[len('/vendor/three/'):] if base == THREE else path.lstrip('/')
        target = (base / (rel or 'index.html')).resolve()
        if not target.is_relative_to(base.resolve()): return str(ROOT/'not-found')
        return str(target)

    def end_headers(self):
        self.send_header('Cache-Control','no-cache')
        super().end_headers()

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=8765)
    args=p.parse_args(); ensure_runtime()
    print(f'Watch Game: http://127.0.0.1:{args.port}',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
